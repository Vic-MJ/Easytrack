--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE jasanaordenes;
--
-- Name: jasanaordenes; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE jasanaordenes WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'es_MX.UTF-8';


ALTER DATABASE jasanaordenes OWNER TO postgres;

\unrestrict (null)
\connect jasanaordenes
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: area; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.area AS ENUM (
    'patronaje',
    'corte',
    'bordado',
    'ensamble',
    'plancha',
    'calidad',
    'operaciones',
    'admin',
    'envios',
    'almacen',
    'diseño',
    'maquilas'
);


ALTER TYPE public.area OWNER TO postgres;

--
-- Name: material_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.material_status AS ENUM (
    'disponible',
    'falta_parcial',
    'no_disponible'
);


ALTER TYPE public.material_status OWNER TO postgres;

--
-- Name: notification_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.notification_type AS ENUM (
    'transfer_request',
    'transfer_accepted',
    'transfer_rejected',
    'order_completed',
    'new_reposition',
    'reposition_transfer',
    'reposition_approved',
    'reposition_rejected',
    'reposition_completed',
    'reposition_deleted',
    'reposition_cancelled',
    'reposition_paused',
    'reposition_resumed',
    'reposition_received',
    'transfer_processed',
    'completion_approval_needed',
    'partial_transfer_warning',
    'reposition_resubmitted',
    'reposition_reactivated',
    'reposition_canceled'
);


ALTER TYPE public.notification_type OWNER TO postgres;

--
-- Name: order_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.order_status AS ENUM (
    'active',
    'completed',
    'cancelled',
    'paused'
);


ALTER TYPE public.order_status OWNER TO postgres;

--
-- Name: reposition_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reposition_status AS ENUM (
    'pendiente',
    'aprobado',
    'completado',
    'cancelado',
    'eliminado',
    'rechazado'
);


ALTER TYPE public.reposition_status OWNER TO postgres;

--
-- Name: reposition_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.reposition_type AS ENUM (
    'reposición',
    'reproceso'
);


ALTER TYPE public.reposition_type OWNER TO postgres;

--
-- Name: transfer_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transfer_status AS ENUM (
    'pending',
    'accepted',
    'rejected'
);


ALTER TYPE public.transfer_status OWNER TO postgres;

--
-- Name: urgency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.urgency AS ENUM (
    'urgente',
    'intermedio',
    'poco_urgente'
);


ALTER TYPE public.urgency OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_passwords; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_passwords (
    id integer NOT NULL,
    password text NOT NULL,
    created_by integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admin_passwords OWNER TO postgres;

--
-- Name: admin_passwords_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_passwords_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_passwords_id_seq OWNER TO postgres;

--
-- Name: admin_passwords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_passwords_id_seq OWNED BY public.admin_passwords.id;


--
-- Name: agenda_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agenda_events (
    id integer NOT NULL,
    created_by integer NOT NULL,
    assigned_to_area public.area NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    date character varying(10) NOT NULL,
    "time" character varying(5) NOT NULL,
    priority character varying(10) DEFAULT 'media'::character varying NOT NULL,
    status character varying(15) DEFAULT 'pendiente'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.agenda_events OWNER TO postgres;

--
-- Name: agenda_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.agenda_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agenda_events_id_seq OWNER TO postgres;

--
-- Name: agenda_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.agenda_events_id_seq OWNED BY public.agenda_events.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    filename text NOT NULL,
    original_name text NOT NULL,
    size integer NOT NULL,
    path text NOT NULL,
    order_id integer,
    reposition_id integer,
    uploaded_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO postgres;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type public.notification_type NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    transfer_id integer,
    order_id integer,
    reposition_id integer,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: order_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_history (
    id integer NOT NULL,
    order_id integer NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    from_area public.area,
    to_area public.area,
    pieces integer,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_history OWNER TO postgres;

--
-- Name: order_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_history_id_seq OWNER TO postgres;

--
-- Name: order_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_history_id_seq OWNED BY public.order_history.id;


--
-- Name: order_pieces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_pieces (
    id integer NOT NULL,
    order_id integer NOT NULL,
    area public.area NOT NULL,
    pieces integer NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.order_pieces OWNER TO postgres;

--
-- Name: order_pieces_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_pieces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_pieces_id_seq OWNER TO postgres;

--
-- Name: order_pieces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_pieces_id_seq OWNED BY public.order_pieces.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    folio text NOT NULL,
    cliente_hotel text NOT NULL,
    no_solicitud text NOT NULL,
    no_hoja text,
    modelo text NOT NULL,
    tipo_prenda text NOT NULL,
    color text NOT NULL,
    tela text NOT NULL,
    total_piezas integer NOT NULL,
    current_area public.area DEFAULT 'corte'::public.area NOT NULL,
    status public.order_status DEFAULT 'active'::public.order_status NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    completed_at timestamp without time zone
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: reposition_contrast_fabrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_contrast_fabrics (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    tela text NOT NULL,
    color text NOT NULL,
    consumo real NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    ubicacion text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.reposition_contrast_fabrics OWNER TO postgres;

--
-- Name: reposition_contrast_fabrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_contrast_fabrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_contrast_fabrics_id_seq OWNER TO postgres;

--
-- Name: reposition_contrast_fabrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_contrast_fabrics_id_seq OWNED BY public.reposition_contrast_fabrics.id;


--
-- Name: reposition_folio_counters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_folio_counters (
    month_year character varying(5) NOT NULL,
    current_value integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.reposition_folio_counters OWNER TO postgres;

--
-- Name: reposition_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_history (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    from_area character varying(50),
    to_area character varying(50),
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reposition_history OWNER TO postgres;

--
-- Name: reposition_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_history_id_seq OWNER TO postgres;

--
-- Name: reposition_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_history_id_seq OWNED BY public.reposition_history.id;


--
-- Name: reposition_materials; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_materials (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    material_status public.material_status DEFAULT 'disponible'::public.material_status NOT NULL,
    missing_materials text,
    notes text,
    is_paused boolean DEFAULT false NOT NULL,
    pause_reason text,
    paused_by integer,
    paused_at timestamp without time zone,
    resumed_by integer,
    resumed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reposition_materials OWNER TO postgres;

--
-- Name: reposition_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_materials_id_seq OWNER TO postgres;

--
-- Name: reposition_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_materials_id_seq OWNED BY public.reposition_materials.id;


--
-- Name: reposition_pieces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_pieces (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    talla text NOT NULL,
    cantidad integer NOT NULL,
    folio_original text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    unit character varying(20) DEFAULT 'piezas'::character varying,
    reposition_product_id integer
);


ALTER TABLE public.reposition_pieces OWNER TO postgres;

--
-- Name: reposition_pieces_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_pieces_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_pieces_id_seq OWNER TO postgres;

--
-- Name: reposition_pieces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_pieces_id_seq OWNED BY public.reposition_pieces.id;


--
-- Name: reposition_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_products (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    modelo_prenda text NOT NULL,
    tela text NOT NULL,
    color text NOT NULL,
    tipo_pieza text NOT NULL,
    consumo_tela real,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reposition_products OWNER TO postgres;

--
-- Name: reposition_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_products_id_seq OWNER TO postgres;

--
-- Name: reposition_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_products_id_seq OWNED BY public.reposition_products.id;


--
-- Name: reposition_timers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_timers (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    area public.area NOT NULL,
    user_id integer NOT NULL,
    start_time timestamp without time zone,
    end_time timestamp without time zone,
    elapsed_minutes real,
    is_running boolean DEFAULT false,
    manual_start_time character varying(5),
    manual_end_time character varying(5),
    manual_date character varying(10),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    manual_end_date character varying(10)
);


ALTER TABLE public.reposition_timers OWNER TO postgres;

--
-- Name: reposition_timers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_timers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_timers_id_seq OWNER TO postgres;

--
-- Name: reposition_timers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_timers_id_seq OWNED BY public.reposition_timers.id;


--
-- Name: reposition_transfers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reposition_transfers (
    id integer NOT NULL,
    reposition_id integer NOT NULL,
    from_area character varying(50) NOT NULL,
    to_area character varying(50) NOT NULL,
    notes text,
    created_by integer NOT NULL,
    processed_by integer,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone
);


ALTER TABLE public.reposition_transfers OWNER TO postgres;

--
-- Name: reposition_transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reposition_transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.reposition_transfers_id_seq OWNER TO postgres;

--
-- Name: reposition_transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reposition_transfers_id_seq OWNED BY public.reposition_transfers.id;


--
-- Name: repositions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repositions (
    id integer NOT NULL,
    folio text NOT NULL,
    type public.reposition_type NOT NULL,
    solicitante_nombre text NOT NULL,
    solicitante_area public.area NOT NULL,
    fecha_solicitud timestamp without time zone DEFAULT now() NOT NULL,
    no_solicitud text NOT NULL,
    no_hoja text,
    fecha_corte text,
    causante_dano text NOT NULL,
    tipo_accidente text NOT NULL,
    otro_accidente text,
    descripcion_suceso text NOT NULL,
    modelo_prenda text NOT NULL,
    tela text NOT NULL,
    color text NOT NULL,
    tipo_pieza text NOT NULL,
    consumo_tela real,
    urgencia public.urgency NOT NULL,
    observaciones text,
    materiales_implicados text,
    volver_hacer text,
    current_area public.area NOT NULL,
    status public.reposition_status DEFAULT 'pendiente'::public.reposition_status NOT NULL,
    created_by integer NOT NULL,
    approved_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    approved_at timestamp without time zone,
    completed_at timestamp without time zone,
    rejection_reason text,
    area_causante_dano public.area
);


ALTER TABLE public.repositions OWNER TO postgres;

--
-- Name: repositions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repositions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.repositions_id_seq OWNER TO postgres;

--
-- Name: repositions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repositions_id_seq OWNED BY public.repositions.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_settings (
    key text NOT NULL,
    value text NOT NULL,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_settings OWNER TO postgres;

--
-- Name: transfers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transfers (
    id integer NOT NULL,
    order_id integer NOT NULL,
    from_area public.area NOT NULL,
    to_area public.area NOT NULL,
    pieces integer NOT NULL,
    status public.transfer_status DEFAULT 'pending'::public.transfer_status NOT NULL,
    notes text,
    created_by integer NOT NULL,
    processed_by integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    processed_at timestamp without time zone
);


ALTER TABLE public.transfers OWNER TO postgres;

--
-- Name: transfers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transfers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transfers_id_seq OWNER TO postgres;

--
-- Name: transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transfers_id_seq OWNED BY public.transfers.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    area public.area NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_passwords id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_passwords ALTER COLUMN id SET DEFAULT nextval('public.admin_passwords_id_seq'::regclass);


--
-- Name: agenda_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agenda_events ALTER COLUMN id SET DEFAULT nextval('public.agenda_events_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: order_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_history ALTER COLUMN id SET DEFAULT nextval('public.order_history_id_seq'::regclass);


--
-- Name: order_pieces id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_pieces ALTER COLUMN id SET DEFAULT nextval('public.order_pieces_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: reposition_contrast_fabrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_contrast_fabrics ALTER COLUMN id SET DEFAULT nextval('public.reposition_contrast_fabrics_id_seq'::regclass);


--
-- Name: reposition_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_history ALTER COLUMN id SET DEFAULT nextval('public.reposition_history_id_seq'::regclass);


--
-- Name: reposition_materials id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_materials ALTER COLUMN id SET DEFAULT nextval('public.reposition_materials_id_seq'::regclass);


--
-- Name: reposition_pieces id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_pieces ALTER COLUMN id SET DEFAULT nextval('public.reposition_pieces_id_seq'::regclass);


--
-- Name: reposition_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_products ALTER COLUMN id SET DEFAULT nextval('public.reposition_products_id_seq'::regclass);


--
-- Name: reposition_timers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_timers ALTER COLUMN id SET DEFAULT nextval('public.reposition_timers_id_seq'::regclass);


--
-- Name: reposition_transfers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_transfers ALTER COLUMN id SET DEFAULT nextval('public.reposition_transfers_id_seq'::regclass);


--
-- Name: repositions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositions ALTER COLUMN id SET DEFAULT nextval('public.repositions_id_seq'::regclass);


--
-- Name: transfers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers ALTER COLUMN id SET DEFAULT nextval('public.transfers_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admin_passwords; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_passwords (id, password, created_by, is_active, created_at) FROM stdin;
\.
COPY public.admin_passwords (id, password, created_by, is_active, created_at) FROM '$$PATH$$/3706.dat';

--
-- Data for Name: agenda_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agenda_events (id, created_by, assigned_to_area, title, description, date, "time", priority, status, created_at, updated_at) FROM stdin;
\.
COPY public.agenda_events (id, created_by, assigned_to_area, title, description, date, "time", priority, status, created_at, updated_at) FROM '$$PATH$$/3708.dat';

--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (id, filename, original_name, size, path, order_id, reposition_id, uploaded_by, created_at) FROM stdin;
\.
COPY public.documents (id, filename, original_name, size, path, order_id, reposition_id, uploaded_by, created_at) FROM '$$PATH$$/3710.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, user_id, type, title, message, transfer_id, order_id, reposition_id, read, created_at) FROM stdin;
\.
COPY public.notifications (id, user_id, type, title, message, transfer_id, order_id, reposition_id, read, created_at) FROM '$$PATH$$/3712.dat';

--
-- Data for Name: order_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_history (id, order_id, action, description, from_area, to_area, pieces, user_id, created_at) FROM stdin;
\.
COPY public.order_history (id, order_id, action, description, from_area, to_area, pieces, user_id, created_at) FROM '$$PATH$$/3714.dat';

--
-- Data for Name: order_pieces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_pieces (id, order_id, area, pieces, updated_at) FROM stdin;
\.
COPY public.order_pieces (id, order_id, area, pieces, updated_at) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, folio, cliente_hotel, no_solicitud, no_hoja, modelo, tipo_prenda, color, tela, total_piezas, current_area, status, created_by, created_at, completed_at) FROM stdin;
\.
COPY public.orders (id, folio, cliente_hotel, no_solicitud, no_hoja, modelo, tipo_prenda, color, tela, total_piezas, current_area, status, created_by, created_at, completed_at) FROM '$$PATH$$/3718.dat';

--
-- Data for Name: reposition_contrast_fabrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_contrast_fabrics (id, reposition_id, tela, color, consumo, created_at, ubicacion) FROM stdin;
\.
COPY public.reposition_contrast_fabrics (id, reposition_id, tela, color, consumo, created_at, ubicacion) FROM '$$PATH$$/3720.dat';

--
-- Data for Name: reposition_folio_counters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_folio_counters (month_year, current_value) FROM stdin;
\.
COPY public.reposition_folio_counters (month_year, current_value) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: reposition_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_history (id, reposition_id, action, description, from_area, to_area, user_id, created_at) FROM stdin;
\.
COPY public.reposition_history (id, reposition_id, action, description, from_area, to_area, user_id, created_at) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: reposition_materials; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_materials (id, reposition_id, material_status, missing_materials, notes, is_paused, pause_reason, paused_by, paused_at, resumed_by, resumed_at, created_at, updated_at) FROM stdin;
\.
COPY public.reposition_materials (id, reposition_id, material_status, missing_materials, notes, is_paused, pause_reason, paused_by, paused_at, resumed_by, resumed_at, created_at, updated_at) FROM '$$PATH$$/3725.dat';

--
-- Data for Name: reposition_pieces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_pieces (id, reposition_id, talla, cantidad, folio_original, created_at, unit, reposition_product_id) FROM stdin;
\.
COPY public.reposition_pieces (id, reposition_id, talla, cantidad, folio_original, created_at, unit, reposition_product_id) FROM '$$PATH$$/3727.dat';

--
-- Data for Name: reposition_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_products (id, reposition_id, modelo_prenda, tela, color, tipo_pieza, consumo_tela, created_at) FROM stdin;
\.
COPY public.reposition_products (id, reposition_id, modelo_prenda, tela, color, tipo_pieza, consumo_tela, created_at) FROM '$$PATH$$/3729.dat';

--
-- Data for Name: reposition_timers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_timers (id, reposition_id, area, user_id, start_time, end_time, elapsed_minutes, is_running, manual_start_time, manual_end_time, manual_date, created_at, manual_end_date) FROM stdin;
\.
COPY public.reposition_timers (id, reposition_id, area, user_id, start_time, end_time, elapsed_minutes, is_running, manual_start_time, manual_end_time, manual_date, created_at, manual_end_date) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: reposition_transfers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reposition_transfers (id, reposition_id, from_area, to_area, notes, created_by, processed_by, status, created_at, processed_at) FROM stdin;
\.
COPY public.reposition_transfers (id, reposition_id, from_area, to_area, notes, created_by, processed_by, status, created_at, processed_at) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: repositions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.repositions (id, folio, type, solicitante_nombre, solicitante_area, fecha_solicitud, no_solicitud, no_hoja, fecha_corte, causante_dano, tipo_accidente, otro_accidente, descripcion_suceso, modelo_prenda, tela, color, tipo_pieza, consumo_tela, urgencia, observaciones, materiales_implicados, volver_hacer, current_area, status, created_by, approved_by, created_at, approved_at, completed_at, rejection_reason, area_causante_dano) FROM stdin;
\.
COPY public.repositions (id, folio, type, solicitante_nombre, solicitante_area, fecha_solicitud, no_solicitud, no_hoja, fecha_corte, causante_dano, tipo_accidente, otro_accidente, descripcion_suceso, modelo_prenda, tela, color, tipo_pieza, consumo_tela, urgencia, observaciones, materiales_implicados, volver_hacer, current_area, status, created_by, approved_by, created_at, approved_at, completed_at, rejection_reason, area_causante_dano) FROM '$$PATH$$/3735.dat';

--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (sid, sess, expire) FROM stdin;
\.
COPY public.session (sid, sess, expire) FROM '$$PATH$$/3737.dat';

--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_settings (key, value, updated_by, updated_at) FROM stdin;
\.
COPY public.system_settings (key, value, updated_by, updated_at) FROM '$$PATH$$/3738.dat';

--
-- Data for Name: transfers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transfers (id, order_id, from_area, to_area, pieces, status, notes, created_by, processed_by, created_at, processed_at) FROM stdin;
\.
COPY public.transfers (id, order_id, from_area, to_area, pieces, status, notes, created_by, processed_by, created_at, processed_at) FROM '$$PATH$$/3739.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, name, area, created_at, is_active) FROM stdin;
\.
COPY public.users (id, username, password, name, area, created_at, is_active) FROM '$$PATH$$/3741.dat';

--
-- Name: admin_passwords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_passwords_id_seq', 1, true);


--
-- Name: agenda_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.agenda_events_id_seq', 1, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_id_seq', 2, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 10854, true);


--
-- Name: order_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_history_id_seq', 1, true);


--
-- Name: order_pieces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_pieces_id_seq', 1, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, true);


--
-- Name: reposition_contrast_fabrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_contrast_fabrics_id_seq', 1, true);


--
-- Name: reposition_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_history_id_seq', 6850, true);


--
-- Name: reposition_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_materials_id_seq', 1, true);


--
-- Name: reposition_pieces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_pieces_id_seq', 1579, true);


--
-- Name: reposition_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_products_id_seq', 1151, true);


--
-- Name: reposition_timers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_timers_id_seq', 929, true);


--
-- Name: reposition_transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reposition_transfers_id_seq', 1673, true);


--
-- Name: repositions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repositions_id_seq', 818, true);


--
-- Name: transfers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transfers_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 16, true);


--
-- Name: admin_passwords admin_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_passwords
    ADD CONSTRAINT admin_passwords_pkey PRIMARY KEY (id);


--
-- Name: agenda_events agenda_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agenda_events
    ADD CONSTRAINT agenda_events_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: order_history order_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_history
    ADD CONSTRAINT order_history_pkey PRIMARY KEY (id);


--
-- Name: order_pieces order_pieces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_pieces
    ADD CONSTRAINT order_pieces_pkey PRIMARY KEY (id);


--
-- Name: orders orders_folio_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_folio_key UNIQUE (folio);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: reposition_contrast_fabrics reposition_contrast_fabrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_contrast_fabrics
    ADD CONSTRAINT reposition_contrast_fabrics_pkey PRIMARY KEY (id);


--
-- Name: reposition_folio_counters reposition_folio_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_folio_counters
    ADD CONSTRAINT reposition_folio_counters_pkey PRIMARY KEY (month_year);


--
-- Name: reposition_history reposition_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_history
    ADD CONSTRAINT reposition_history_pkey PRIMARY KEY (id);


--
-- Name: reposition_materials reposition_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_materials
    ADD CONSTRAINT reposition_materials_pkey PRIMARY KEY (id);


--
-- Name: reposition_pieces reposition_pieces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_pieces
    ADD CONSTRAINT reposition_pieces_pkey PRIMARY KEY (id);


--
-- Name: reposition_products reposition_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_products
    ADD CONSTRAINT reposition_products_pkey PRIMARY KEY (id);


--
-- Name: reposition_timers reposition_timers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_timers
    ADD CONSTRAINT reposition_timers_pkey PRIMARY KEY (id);


--
-- Name: reposition_transfers reposition_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_transfers
    ADD CONSTRAINT reposition_transfers_pkey PRIMARY KEY (id);


--
-- Name: repositions repositions_folio_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositions
    ADD CONSTRAINT repositions_folio_key UNIQUE (folio);


--
-- Name: repositions repositions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositions
    ADD CONSTRAINT repositions_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (key);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_notifications_reposition_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_notifications_reposition_id ON public.notifications USING btree (reposition_id);


--
-- Name: idx_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_session_expire ON public.session USING btree (expire);


--
-- Name: orders_folio_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX orders_folio_unique ON public.orders USING btree (folio);


--
-- Name: users_username_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_username_unique ON public.users USING btree (username);


--
-- Name: admin_passwords admin_passwords_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_passwords
    ADD CONSTRAINT admin_passwords_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: agenda_events agenda_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agenda_events
    ADD CONSTRAINT agenda_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: documents documents_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: documents documents_reposition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_reposition_id_fkey FOREIGN KEY (reposition_id) REFERENCES public.repositions(id) ON DELETE CASCADE;


--
-- Name: documents documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: reposition_contrast_fabrics reposition_contrast_fabrics_reposition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_contrast_fabrics
    ADD CONSTRAINT reposition_contrast_fabrics_reposition_id_fkey FOREIGN KEY (reposition_id) REFERENCES public.repositions(id) ON DELETE CASCADE;


--
-- Name: reposition_history reposition_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_history
    ADD CONSTRAINT reposition_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: reposition_materials reposition_materials_paused_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_materials
    ADD CONSTRAINT reposition_materials_paused_by_fkey FOREIGN KEY (paused_by) REFERENCES public.users(id);


--
-- Name: reposition_materials reposition_materials_reposition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_materials
    ADD CONSTRAINT reposition_materials_reposition_id_fkey FOREIGN KEY (reposition_id) REFERENCES public.repositions(id) ON DELETE CASCADE;


--
-- Name: reposition_materials reposition_materials_resumed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_materials
    ADD CONSTRAINT reposition_materials_resumed_by_fkey FOREIGN KEY (resumed_by) REFERENCES public.users(id);


--
-- Name: reposition_pieces reposition_pieces_product_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_pieces
    ADD CONSTRAINT reposition_pieces_product_fkey FOREIGN KEY (reposition_product_id) REFERENCES public.reposition_products(id) ON DELETE CASCADE;


--
-- Name: reposition_products reposition_products_reposition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_products
    ADD CONSTRAINT reposition_products_reposition_id_fkey FOREIGN KEY (reposition_id) REFERENCES public.repositions(id) ON DELETE CASCADE;


--
-- Name: reposition_timers reposition_timers_reposition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_timers
    ADD CONSTRAINT reposition_timers_reposition_id_fkey FOREIGN KEY (reposition_id) REFERENCES public.repositions(id) ON DELETE CASCADE;


--
-- Name: reposition_timers reposition_timers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_timers
    ADD CONSTRAINT reposition_timers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: reposition_transfers reposition_transfers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_transfers
    ADD CONSTRAINT reposition_transfers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: reposition_transfers reposition_transfers_processed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reposition_transfers
    ADD CONSTRAINT reposition_transfers_processed_by_fkey FOREIGN KEY (processed_by) REFERENCES public.users(id);


--
-- Name: repositions repositions_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositions
    ADD CONSTRAINT repositions_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: repositions repositions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repositions
    ADD CONSTRAINT repositions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

